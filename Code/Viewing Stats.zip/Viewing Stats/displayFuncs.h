#include "states.h"
#include "main.h"
#include "GameCharacters.h"
#include "GameMap.h"

void Display_Stats(Character* character, int select);
void View_Character_Info(Character* character);
